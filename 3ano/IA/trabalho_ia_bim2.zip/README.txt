Alunos: Theo Okagawa Rodrigues; Lissa Guirau Kawasaki
Data: 29/07/2025

Instruções:
    1 - Descompacte o arquivo zip
    2 - Navegue até a pasta do projeto
    3 - Crie e ative um ambiente virtual - opcional
        *No terminal Windows: 
        python3 -m venv meu_ambiente
        source meu_ambiente/Scripts/activate.bat

    4 - Instale as dependencias
        pip install -r requirements.txt
    
    5 - Rode o programa
        *na pasta do projeto*
        python3 diabetesAnalysis.py